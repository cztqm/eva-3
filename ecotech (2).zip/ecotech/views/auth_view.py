"""Interacción de autenticación por consola."""

from getpass import getpass

from controllers.auth_controller import AuthController
from views.utils import leer_entero, leer_texto


class AuthView:
    def __init__(self, controller: AuthController) -> None:
        self.controller = controller

    def menu_acceso(self) -> bool:
        """Muestra el menú de acceso y retorna True tras autenticar."""
        while True:
            print(
                "\n=== Acceso EcoTech Solutions ===\n"
                "1. Iniciar sesión\n"
                "2. Crear cuenta\n"
                "0. Salir"
            )
            opcion = leer_entero("Seleccione una opción: ", minimo=0)
            if opcion == 0:
                print("Hasta luego.")
                return False
            if opcion == 1:
                if self._iniciar_sesion():
                    return True
            elif opcion == 2:
                self._crear_cuenta()
            else:
                print("Opción no válida.")

    def _iniciar_sesion(self) -> bool:
        print("\n--- Inicio de sesión (0 para regresar) ---")
        email = self._leer_email_o_regresar()
        if email is None:
            return False
        contrasena = self._leer_contrasena("Contraseña (vacía para regresar): ")
        if contrasena is None:
            return False
        try:
            autenticado = self.controller.autenticar(email, contrasena)
        except ValueError as exc:
            print(str(exc))
            return False
        except RuntimeError:
            print("No fue posible validar las credenciales en este momento.")
            return False
        if not autenticado:
            print("Credenciales incorrectas.")
            return False
        print("Inicio de sesión correcto.")
        return True

    def _crear_cuenta(self) -> None:
        print("\n--- Crear cuenta (0 para regresar) ---")
        email = self._leer_email_o_regresar()
        if email is None:
            return
        contrasena = self._leer_contrasena("Contraseña (vacía para regresar): ")
        if contrasena is None:
            return
        confirmacion = self._leer_contrasena("Repita la contraseña: ")
        if confirmacion is None:
            return
        if contrasena != confirmacion:
            print("Las contraseñas no coinciden. No se creó la cuenta.")
            return
        try:
            self.controller.crear_cuenta(email, contrasena)
        except (RuntimeError, ValueError) as exc:
            print(f"No se pudo crear la cuenta: {exc}")
            return
        print("Cuenta creada con acceso completo. Ahora puede iniciar sesión.")

    @staticmethod
    def _leer_email_o_regresar() -> str | None:
        email = leer_texto("Correo (0 para regresar): ")
        return None if email == "0" else email

    @staticmethod
    def _leer_contrasena(mensaje: str) -> str | None:
        contrasena = getpass(mensaje)
        if not contrasena.strip():
            return None
        return contrasena
