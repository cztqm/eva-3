"""Presentación por consola de información de servicios externos."""

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from controllers.external_api_controller import (
    ExternalAPIController,
    ExternalAPIError,
)
from views.utils import leer_texto


class ExternalAPIView:
    def __init__(self, controller: ExternalAPIController) -> None:
        self.controller = controller

    def menu(self) -> None:
        while True:
            print(
                "\n--- Información externa ---\n"
                "1. Consultar clima\n"
                "2. Consultar cotización del dólar\n"
                "0. Volver al menú principal"
            )
            opcion = leer_texto("Seleccione una opción: ")
            if opcion == "0":
                return
            try:
                if opcion == "1":
                    self._mostrar_clima()
                elif opcion == "2":
                    self._mostrar_dolar()
                else:
                    print("Opción no válida.")
            except (ExternalAPIError, ValueError) as exc:
                print(f"No se pudo completar la consulta: {exc}")

    def _mostrar_clima(self) -> None:
        ciudad = leer_texto("Ciudad: ")
        clima = self.controller.obtener_clima(ciudad)
        print(
            f"Clima en {clima['ciudad']}: {clima['descripcion']}, "
            f"{clima['temperatura']} °C; sensación térmica "
            f"{clima['sensacion']} °C; humedad {clima['humedad']}%."
        )

    def _mostrar_dolar(self) -> None:
        indicador = self.controller.obtener_dolar()
        print(
            "\n=== Dólar Observado ===\n"
            f"Fecha: {indicador['fecha']}\n"
            f"Valor: ${indicador['valor']:,.2f} CLP"
        )


if __name__ == "__main__":
    from main import main

    main()
