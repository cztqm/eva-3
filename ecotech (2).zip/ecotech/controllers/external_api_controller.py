"""Consumo y validación de las APIs públicas de clima e indicadores."""

from datetime import datetime
import math
from typing import Any

import requests

from config.external_apis import (
    DOLLAR_URL,
    GEOCODING_URL,
    HTTP_TIMEOUT,
    WEATHER_URL,
)


class ExternalAPIError(Exception):
    """Error externo con un mensaje seguro para mostrar en consola."""


class ExternalAPIController:
    """Obtiene datos públicos y expone únicamente los campos necesarios."""

    def obtener_clima(self, ciudad: str) -> dict[str, str]:
        ciudad = self._validar_ciudad(ciudad)
        ubicaciones = self._obtener_json(
            GEOCODING_URL,
            params={
                "name": ciudad,
                "count": 10,
                "language": "es",
                "format": "json",
                "countryCode": "CL",
            },
        ).get("results")
        if not isinstance(ubicaciones, list) or not ubicaciones:
            raise ExternalAPIError(
                "No se encontró una ciudad de Chile con ese nombre."
            )
        ubicacion = ubicaciones[0]
        if not isinstance(ubicacion, dict) or ubicacion.get("country_code") != "CL":
            raise ExternalAPIError(
                "No se encontró una ciudad de Chile con ese nombre."
            )
        latitud = ubicacion.get("latitude")
        longitud = ubicacion.get("longitude")
        nombre_ciudad = ubicacion.get("name")
        if (
            not isinstance(latitud, (int, float))
            or isinstance(latitud, bool)
            or not self._numero_finito(latitud)
            or not isinstance(longitud, (int, float))
            or isinstance(longitud, bool)
            or not self._numero_finito(longitud)
            or not isinstance(nombre_ciudad, str)
        ):
            raise ExternalAPIError("La ubicación encontrada no es válida.")

        clima = self._obtener_json(
            WEATHER_URL,
            params={
                "latitude": latitud,
                "longitude": longitud,
                "current": (
                    "temperature_2m,relative_humidity_2m,"
                    "apparent_temperature,weather_code"
                ),
                "timezone": "auto",
            },
        ).get("current")
        if not isinstance(clima, dict):
            raise ExternalAPIError("La respuesta del servicio de clima no es válida.")
        codigo = clima.get("weather_code")
        if not isinstance(codigo, int) or isinstance(codigo, bool):
            raise ExternalAPIError("La respuesta del servicio de clima no es válida.")
        return {
            "ciudad": nombre_ciudad,
            "descripcion": self._descripcion_clima(codigo),
            "temperatura": self._campo_numerico_texto(clima, "temperature_2m"),
            "sensacion": self._campo_numerico_texto(clima, "apparent_temperature"),
            "humedad": self._campo_numerico_texto(
                clima, "relative_humidity_2m"
            ),
        }

    def obtener_dolar(self) -> dict[str, str | float]:
        datos = self._obtener_json(DOLLAR_URL)
        if datos.get("codigo") != "dolar" or datos.get("nombre") != "Dólar observado":
            raise ExternalAPIError(
                "La respuesta del indicador económico no corresponde al dólar observado."
            )
        serie = datos.get("serie")
        if not isinstance(serie, list) or not serie or not isinstance(serie[0], dict):
            raise ExternalAPIError(
                "El servicio del indicador económico no devolvió observaciones."
            )
        registro = serie[0]
        valor = self._validar_valor_cotizacion(registro, "valor")
        fecha = registro.get("fecha")
        if not isinstance(fecha, str) or not fecha.strip():
            raise ExternalAPIError("La fecha del indicador económico no es válida.")
        return {
            "fecha": self._normalizar_fecha_serie(fecha),
            "valor": valor,
        }

    @staticmethod
    def _validar_ciudad(ciudad: str) -> str:
        if not isinstance(ciudad, str):
            raise ValueError("Ingrese una ciudad válida.")
        ciudad = ciudad.strip()
        if (
            not ciudad
            or len(ciudad) > 80
            or not all(caracter.isalpha() or caracter in " -'" for caracter in ciudad)
        ):
            raise ValueError("Ingrese una ciudad válida.")
        return ciudad

    @staticmethod
    def _obtener_json(
        url: str, params: dict[str, str | int | float] | None = None
    ) -> dict[str, Any]:
        try:
            respuesta = requests.get(url, params=params, timeout=HTTP_TIMEOUT)
            respuesta.raise_for_status()
            datos = respuesta.json()
        except requests.exceptions.Timeout as exc:
            raise ExternalAPIError(
                "El servicio externo tardó demasiado en responder."
            ) from exc
        except requests.exceptions.HTTPError as exc:
            estado = exc.response.status_code if exc.response is not None else None
            if estado == 404:
                mensaje = "El servicio externo no encontró los datos solicitados (404)."
            else:
                mensaje = "El servicio externo respondió con un error HTTP."
            raise ExternalAPIError(mensaje) from exc
        except requests.exceptions.ConnectionError as exc:
            raise ExternalAPIError(
                "No fue posible conectarse con el servicio externo."
            ) from exc
        except requests.exceptions.JSONDecodeError as exc:
            raise ExternalAPIError(
                "El servicio externo devolvió una respuesta JSON inválida."
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise ExternalAPIError(
                "No fue posible completar la consulta al servicio externo."
            ) from exc
        except ValueError as exc:
            raise ExternalAPIError(
                "El servicio externo devolvió una respuesta JSON inválida."
            ) from exc

        if not isinstance(datos, dict):
            raise ExternalAPIError("El servicio externo devolvió datos inesperados.")
        return datos

    @classmethod
    def _campo_numerico_texto(cls, datos: dict[str, Any], campo: str) -> str:
        valor = datos.get(campo)
        if (
            not isinstance(valor, (int, float))
            or isinstance(valor, bool)
            or not cls._numero_finito(valor)
        ):
            raise ExternalAPIError("La respuesta del servicio de clima no es válida.")
        return str(valor)

    @staticmethod
    def _descripcion_clima(codigo: int) -> str:
        descripciones = {
            0: "Despejado",
            1: "Mayormente despejado",
            2: "Parcialmente nublado",
            3: "Nublado",
            45: "Niebla",
            48: "Niebla con escarcha",
            51: "Llovizna ligera",
            53: "Llovizna moderada",
            55: "Llovizna intensa",
            56: "Llovizna helada ligera",
            57: "Llovizna helada intensa",
            61: "Lluvia ligera",
            63: "Lluvia moderada",
            65: "Lluvia intensa",
            66: "Lluvia helada ligera",
            67: "Lluvia helada intensa",
            71: "Nevada ligera",
            73: "Nevada moderada",
            75: "Nevada intensa",
            77: "Granizo pequeño",
            80: "Chubascos ligeros",
            81: "Chubascos moderados",
            82: "Chubascos intensos",
            85: "Chubascos de nieve ligeros",
            86: "Chubascos de nieve intensos",
            95: "Tormenta",
            96: "Tormenta con granizo ligero",
            99: "Tormenta con granizo intenso",
        }
        return descripciones.get(codigo, "Condición climática no disponible")

    @staticmethod
    def _numero_finito(valor: int | float) -> bool:
        try:
            return math.isfinite(float(valor))
        except (OverflowError, ValueError):
            return False

    @classmethod
    def _validar_valor_cotizacion(cls, datos: dict[str, Any], campo: str) -> float:
        valor = datos.get(campo)
        if (
            isinstance(valor, bool)
            or not isinstance(valor, (int, float, str))
            or not cls._valor_finito(valor)
        ):
            raise ExternalAPIError(
                "La cotización recibida del indicador económico no es válida."
            )
        return float(valor)

    @staticmethod
    def _valor_finito(valor: int | float | str) -> bool:
        try:
            return math.isfinite(float(valor))
        except (OverflowError, ValueError):
            return False

    @staticmethod
    def _normalizar_fecha_serie(fecha: str) -> str:
        try:
            try:
                actualizacion = datetime.fromisoformat(
                    fecha.replace("Z", "+00:00")
                )
            except ValueError:
                actualizacion = datetime.strptime(fecha, "%d-%m-%Y")
        except ValueError as exc:
            raise ExternalAPIError(
                "La fecha del indicador económico no es válida."
            ) from exc
        return actualizacion.strftime("%d-%m-%Y")
