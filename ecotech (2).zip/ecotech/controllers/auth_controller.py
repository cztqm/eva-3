"""Autenticación y configuración inicial de cuentas."""

import re
import sqlite3

from config.database import Database
from models.usuario import Usuario


class AuthController:
    """Valida las credenciales de los usuarios almacenados en SQLite."""

    def __init__(self, database: Database) -> None:
        self.database = database

    def hay_usuarios(self) -> bool:
        try:
            with self.database.transaction() as connection:
                fila = connection.execute("SELECT 1 FROM usuario LIMIT 1").fetchone()
                return fila is not None
        except sqlite3.Error as exc:
            raise RuntimeError("No fue posible consultar las cuentas.") from exc

    def crear_cuenta(self, email: str, contrasena: str) -> None:
        email = self._validar_email(email)
        contrasena = self._texto_requerido(contrasena, "La contraseña", strip=False)
        nombre = email.partition("@")[0].replace(".", " ").replace("_", " ").title()

        try:
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    """INSERT INTO usuario
                       (nombre, email, contrasena_hash, tipo_usuario)
                       VALUES (?, ?, ?, 'administrador')""",
                    (nombre, email, Usuario.generar_hash(contrasena)),
                )
                connection.execute(
                    "INSERT INTO administrador (id_usuario) VALUES (?)",
                    (cursor.lastrowid,),
                )
        except sqlite3.IntegrityError as exc:
            raise RuntimeError("Ese correo ya tiene una cuenta registrada.") from exc
        except sqlite3.Error as exc:
            raise RuntimeError("No fue posible crear la cuenta.") from exc

    def autenticar(self, email: str, contrasena: str) -> bool:
        email = self._validar_email(email)
        contrasena = self._texto_requerido(contrasena, "La contraseña", strip=False)
        try:
            with self.database.transaction() as connection:
                fila = connection.execute(
                    """SELECT nombre, contrasena_hash
                       FROM usuario
                       WHERE email = ? COLLATE NOCASE""",
                    (email,),
                ).fetchone()
        except sqlite3.Error as exc:
            raise RuntimeError("No fue posible validar las credenciales.") from exc
        if fila is None:
            return False
        usuario = Usuario(
            nombre=fila["nombre"],
            email=email,
            contrasena_hash=fila["contrasena_hash"],
        )
        return usuario.autenticar(contrasena)

    @staticmethod
    def _texto_requerido(
        valor: str, campo: str, *, strip: bool = True
    ) -> str:
        if not isinstance(valor, str):
            raise ValueError(f"{campo} es obligatorio.")
        resultado = valor.strip() if strip else valor
        if not resultado.strip():
            raise ValueError(f"{campo} es obligatorio.")
        return resultado

    @classmethod
    def _validar_email(cls, email: str) -> str:
        email = cls._texto_requerido(email, "El correo").lower()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ValueError("Ingrese un correo electrónico válido.")
        return email
