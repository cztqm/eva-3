"""Punto de entrada de la aplicación de consola EcoTech Solutions."""

import sqlite3

from config.database import Database
from controllers.auth_controller import AuthController
from controllers.empleado_controller import EmpleadoController
from controllers.external_api_controller import ExternalAPIController
from controllers.proyecto_controller import ProyectoController
from views.auth_view import AuthView
from views.empleado_view import EmpleadoView
from views.external_api_view import ExternalAPIView
from views.proyecto_view import ProyectoView
from views.utils import leer_entero


def main() -> None:
    database = Database()
    try:
        database.init_db()
    except sqlite3.Error:
        print("No fue posible iniciar la base de datos.")
        return

    auth_view = AuthView(AuthController(database))
    try:
        if not auth_view.menu_acceso():
            return
    except RuntimeError:
        print("No fue posible procesar el acceso. Intente nuevamente.")
        return

    empleado_view = EmpleadoView(EmpleadoController(database))
    proyecto_view = ProyectoView(ProyectoController(database))
    api_view = ExternalAPIView(ExternalAPIController())
    while True:
        print(
            "\n=== EcoTech Solutions ===\n"
            "1. Empleados y horas\n"
            "2. Proyectos y asignaciones\n"
            "3. Información de clima y dólar\n"
            "0. Salir"
        )
        opcion = leer_entero("Seleccione una opción: ", minimo=0)
        if opcion == 0:
            print("Hasta luego.")
            break
        if opcion == 1:
            empleado_view.menu()
        elif opcion == 2:
            proyecto_view.menu()
        elif opcion == 3:
            api_view.menu()
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    main()
