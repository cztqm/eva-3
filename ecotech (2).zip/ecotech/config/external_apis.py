"""Configuración para los servicios HTTP externos."""

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
WEATHER_URL = "https://api.open-meteo.com/v1/forecast"
DOLLAR_URL = "https://mindicador.cl/api/dolar"
HTTP_TIMEOUT = (3.05, 8)
